<template>
    <div class="col-lg-3 mb-4">
    <ul class="list-group" style="background-color: #e6f7ff"> 
        <li class="list-group-item primary" style="background: #074173">
            <div class="d-flex align-items-center">
                <a-avatar :src="userData.imageLink" size="large" />
                <div class="ps-3">
                    <p class="my-0 fs-6 " style="color: white;">{{ userData.username }}</p>

                </div>
            </div>
        </li>

        <li class="list-group-item user-menu" @click="menuClicked('personal-info')">
            <i class="fa-solid fa-user pe-2"></i>Personal Info
        </li>
        <li class="list-group-item user-menu" @click="menuClicked('transaction-history')">
            <i class="fas fa-heart pe-2"></i>Transaction History
        </li>
        <li class="list-group-item user-menu" @click="menuClicked('user-product')">
            <i class="fa-solid fa-burger pe-2"></i>My Product
        </li>
    </ul>

    </div>
  </template>
  
  <script setup>
  const emit = defineEmits(['changeComponents'])
  
  const menuClicked = option => {
    emit("changeComponent", option)
  }
  
  import { computed } from "vue";
  import { useStore } from "vuex"
  
  const store = useStore()
  const userData = computed(() => {
    return store.state.auth.userLogin
  })
  console.log(userData)
  
  </script>
  
  <style scoped>
  .user-menu:hover {
    cursor: pointer;
  }
  
  .active-color {
    color: #4c4ddc;
  }
  
  .inactive-color {
    color: #404040;
  }
  </style>