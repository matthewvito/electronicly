<template>
  <ul class="list-group">
    <li class="list-group-item">
      <div class="d-flex flex-sm-row flex-column justify-content-between align-items-sm-center">
        <div class="mb-3 mb-sm-0">
          <p class="my-0 fs-4 fw-semibold">My Product</p>
          <p class="my-0 text-secondary">Add your product here</p>
        </div>
        <div>
          <button class="btn add-btn px-3 py-2 rounded-pill" @click="$router.push('/new-product')">

            <i class="fa-solid fa-circle-plus pe-2"></i>Add Product


          </button>
        </div>
      </div>
    </li>
    <li class="list-group-item">
      <p class="mt-2 mb-4 fs-5 fw-semibold">Product</p>
      <div class="row">
        <a-row :gutter="[16, 16]">
          <a-col :span="8" v-for="product in products" :key="product.id">
            <a-card :title="product.name" :bordered="false">

              <template #cover>
                <img alt="example" :src="product.image" style="width: 200px; height: 200px; object-fit: cover;" />
              </template>

              <template #actions>
                <a-button @click="deleteProduct(product.id)">Delete</a-button>
                <a-button type="primary" @click="editProduct(product.id)">Edit</a-button>
              </template>

            </a-card>
          </a-col>
        </a-row>




      </div>

    </li>

  </ul>
</template>

<script setup>
// import UserRecipeCard from "./UserRecipeCard.vue";
import { computed } from "vue";
import { useStore } from "vuex";
import { useRouter } from "vue-router"
import { onMounted } from "vue";

const store = useStore();
onMounted(async () => {
  const products = await store.dispatch('product/getProductData')
})

const products = computed(() => {
  const allProduct = store.state.product.products;
  console.log(allProduct)
  const userId = store.state.auth.userLogin.userId;
  return allProduct.filter((product) => product.userId === userId);
})
console.log(products)

import { Modal } from 'antd';

const deleteProduct = async (id) => {
  Modal.confirm({
    title: 'Are you sure you want to delete this product?',
    onOk: async () => {
      await store.dispatch("product/deleteProduct", id)
    },
  });
}

const router = useRouter()

const editProduct = (id) => {
  router.push({
    name: 'EditProduct',
    params: { id }
  })
}


</script>