<template>
    <div class="jumbotron d-flex align-items-center p-4">
        <div class="card mx-4" style="width: 18rem;">
            <div class="card-body">
                <h5 class="card-title">Ready to give you the best electronics ever</h5>
                <p class="btn btn-secondary mt-3">Buy Now!</p>
            </div>

        </div>
        
    </div>
    <section id="company-services" class="padding-large">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 pb-3">
                        <div class="icon-box d-flex">
                            <div class="icon-box-icon pe-3 pb-3">
                                <svg class="cart-outline">
                                    <use xlink:href="#cart-outline" />
                                </svg>
                            </div>
                            <div class="icon-box-content">
                                <h3 class="card-title text-uppercase text-dark">Free delivery</h3>
                                <p>Worried about the delivery?Don't worry! it's free</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 pb-3">
                        <div class="icon-box d-flex">
                            <div class="icon-box-icon pe-3 pb-3">
                                <svg class="quality">
                                    <use xlink:href="#quality" />
                                </svg>
                            </div>
                            <div class="icon-box-content">
                                <h3 class="card-title text-uppercase text-dark">Quality guarantee</h3>
                                <p>Our product have the best quality</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 pb-3">
                        <div class="icon-box d-flex">
                            <div class="icon-box-icon pe-3 pb-3">
                                <svg class="price-tag">
                                    <use xlink:href="#price-tag" />
                                </svg>
                            </div>
                            <div class="icon-box-content">
                                <h3 class="card-title text-uppercase text-dark">Daily offers</h3>
                                <p>Amet consectetur adipi elit loreme ipsum dolor sit.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 pb-3">
                        <div class="icon-box d-flex">
                            <div class="icon-box-icon pe-3 pb-3">
                                <svg class="shield-plus">
                                    <use xlink:href="#shield-plus" />
                                </svg>
                            </div>
                            <div class="icon-box-content">
                                <h3 class="card-title text-uppercase text-dark">100% secure payment</h3>
                                <p>We guarantee that your product will be safe in your hands</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <product-list :products="productData" v-if="productListStatus">

        </product-list>



</template>
<script setup>
import productList from '@/components/product/productList.vue'
import { onMounted, ref } from "vue";
import { useStore } from "vuex";

const store = useStore();
const productListStatus = ref(false);
const productData = ref();


onMounted(async () => {
    try {
        await store.dispatch("product/getProductData");
        productListStatus.value = true;
        productData.value = store.state.product.products;
        console.log(productData.value)
    } catch (error) {
        console.log(error)
    }
})

</script>