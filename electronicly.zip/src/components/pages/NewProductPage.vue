<template>
    <div class="container-md my-5 py-5">
        <form-header></form-header>
        <product-form></product-form>

    </div>
</template>
<script setup>
import ProductForm from '../productForm/ProductForm.vue';
import formHeader from '../productForm/formHeader.vue';
</script>