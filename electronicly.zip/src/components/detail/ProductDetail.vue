<template><a-image :width="200" :src="productDetail.image" class="mb-5" />
<table class="table">
    <tbody>
        <tr>
            <td>Name</td>
            <td>{{ productDetail.name }}</td>
        </tr>
        <tr>
            <td>Price</td>
            <td>{{ `$ ${productDetail.price}` }}</td>
        </tr>
        <tr>
            <td>Color</td>
            <td>{{ productDetail.color }}</td>
        </tr>
        <tr>
            <td>Stock</td>
            <td>{{ productDetail.stock }}</td>
        </tr>
        <tr>
            <td>Description</td>
            <td>{{ productDetail.description }}</td>
        </tr>
    </tbody>
</table>


    <a-space wrap>
        <a-button type="primary" @click="showModal">Add To Cart</a-button>

        <a-button @click="redirectToWhatsapp">Buy Now</a-button>

    </a-space>

    <a-modal v-model:visible="visible" title="Add to Cart" @ok="handleOk">
        <a-input-number v-model:value="quantity" :min="1" />
    </a-modal></template>

<script setup>

import { onMounted, ref } from "vue";
import { useRoute } from "vue-router";
import { useStore } from "vuex";
import { computed, reactive } from "vue";

const store = useStore()
const route = useRoute()

const visible = ref(false)
const quantity = ref(1)

const showModal = () => {
    visible.value = true;
};

const handleOk = () => {
    // Add product to cart with quantity
    store.state.product.cart.push({
        product: productDetail.value,
        quantity: quantity.value
    })
console.log(store.state.product.cart)
    console.log('Adding to cart', quantity.value);
    visible.value = false;
};


onMounted(async () => {
    await store.dispatch("product/getProductDetail", route.params.id)
})

const productDetail = computed(() => {
    return store.state.product.productDetail

})
console.log(productDetail.value)

const redirectToWhatsapp = () => {
    console.log(productDetail)
    let message = `Hello, I want to buy \nProduct: ${store.state.product.productDetail.name}\nColor: ${store.state.product.productDetail.color}\n\nThank you :).`;
    let whatsappUrl = `https://wa.me/?text=${encodeURIComponent(message)}`;
    window.location.href = whatsappUrl;


}

</script>
