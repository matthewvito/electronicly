<template>
    <router-link :to="`/product/${ data.id }`">
        <a-card hoverable style="width: 300px; margin: 20px;">
            <template #cover>
                <img alt="example" :src=" data.image " />
            </template>
            <template #actions>
                <setting-outlined key="setting" />
                <edit-outlined key="edit" />
                <ellipsis-outlined key="ellipsis" />
            </template>
            <a-card-meta :title=" data.name " :description=" `$ ${data.price}` ">
                <template #avatar>
                    <a-avatar :src=" data.image " />
                </template>
            </a-card-meta>
        </a-card>
    </router-link>

</template>

<script setup>
import { SettingOutlined, EditOutlined, EllipsisOutlined } from '@ant-design/icons-vue';
import { arrayType } from 'ant-design-vue/es/_util/type';

defineProps({
    data: { type: Array, require: true, default: false },

})
</script>