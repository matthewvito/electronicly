<template>
  <div class="container-product">

    <product-card
    v-for="(product, index) in products"
    :data="product"
    
    ></product-card>
   

  </div>
</template>
<script setup>
import productCard from './productCard.vue'
defineProps({
  products: Array

})




</script>

<style>
.container-product {
  display: flex;
  justify-content: center;
  margin: 30px;
  flex-wrap: wrap;
}
</style>