<template>
  <div
    class="header__signup col-8 col-sm-4 fw-semibold d-flex justify-content-evenly align-items-center text-decoration-none"
    style="text-align: right">
    <a-button @click="showModal">
      <template #icon><i class="fa-solid fa-cart-shopping"></i></template>

    </a-button>


    <a-modal v-model:visible="visible" title="Your Cart" @ok="handleOk" @cancel="handleCancel">
      <a-card v-for="product in cartData" :key="product.id">
            <a-image width="200" height="200" :src="product.product.image" preview={{ visible: false, mask: true, maskClosable:
                true }} />

        <div>
          <h3>{{ product.product.name }}</h3>
          <p>Price: {{ product.product.price }}</p>
          <p>Quantity: {{ product.quantity }}</p>
          <p>Total: {{ product.quantity * product.product.price }}</p>
        </div>
      </a-card>
    </a-modal>


    <a-dropdown placement="bottom">
      <a class="ant-dropdown-link" slot="overlay" @click="goTo('/user/personal-info')">
        <img :src="userData.imageLink" class="avatar-img" />
      </a>
      <template #overlay>
        <a-menu>
          <a-menu-item>
            <a @click="goTo('/user/personal-info')">Personal Info</a>
          </a-menu-item>
          <a-menu-item>
            <a @click="goTo('/user/favorite-products')">Transaction History</a>
          </a-menu-item>
          <a-menu-item>
            <a @click="goTo('/user/user-product')">My Product</a>
          </a-menu-item>
          <a-menu-item>
            <a @click="logout">Log Out</a>
          </a-menu-item>
        </a-menu>
      </template>
    </a-dropdown>


  </div>
</template>

<script setup>
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import { computed, ref } from 'vue';
import { watchEffect } from 'vue';
import { Dropdown, Menu } from 'ant-design-vue';
import { Modal } from 'ant-design-vue';

const visible = ref(false);
const showModal = () => {
  visible.value = true;
};

const handleOk = async (e) => {
 
  let message = 'Hello, I would like to purchase the following items:\n';
        store.state.product.cart.forEach(item => {
          message += `
            Name: ${item.product.name}
            Color: ${item.product.color}
            Quantity: ${item.quantity}
            Total Price: Rp. ${item.quantity * item.product.price}
            ------------------------
          `;
          
        });
        await store.dispatch('product/addCart', store.state.product.cart)
        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/?text=${encodedMessage}`);

  visible.value = false;

};

const handleCancel = (e) => {
  console.log(e);
  visible.value = false;
};
const store = useStore();
const router = useRouter();
const userData = computed(() => {
  return store.state.auth.userLogin;
})

const cartData = computed(() => {
    return store.state.product.cart;

})

const goTo = (path) => {
  router.push(path);
};


const logout = () => {
  store.commit('auth/setUserLogout');
  router.push('/');
}

// const cart = ref([
//   {
//     id: 1,
//     name: 'Product 1',
//     price: 100,
//     quantity: 2,
//     image: 'https://th.bing.com/th/id/OIP.QGNUJBEED2Yq_vAkVrf88gHaFe?rs=1&pid=ImgDetMain'
//   },
//   {
//     id: 2,
//     name: 'Product 2',
//     price: 200,
//     quantity: 1,
//     image: 'https://th.bing.com/th/id/OIP.QGNUJBEED2Yq_vAkVrf88gHaFe?rs=1&pid=ImgDetMain'
//   }
// ]);

</script>

<style>
.avatar-img {
  width: 32px;
  height: 32px;
  border-radius: 50%;
  object-fit: cover;
}

.icon-container {
  position: relative;
}

.icon-badge {
  position: absolute;
  top: -10px;
  right: -10px;
  padding: 4px 8px;
  border-radius: 50%;
  background-color: red;
  color: white;
  font-size: 7px;
}
</style>