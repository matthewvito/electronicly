<template>
    <router-link to="/signup"
      class="header__signup col-7 col-sm-3 fw-semibold d-flex justify-content-evenly align-items-center text-decoration-none"
      style="color: #4c4ddc; text-align: right"
    >
      <i class="fa-solid fa-user"></i>
      <p class="mb-0">Sign Up</p>
    </router-link>

    

  </template>
