<template>
<header class="shadow-sm container-fluid bg-white py-3 border-bottom fixed-top">
        <div class="container-md d-flex justify-content-between align-items-center">
            <router-link to="/" class="header__logo col-2 col-sm-1">
            <img src="@/assets/logo.jpg" alt="Logo" class="logo_header">
            </router-link>
        
            <navigation-bar></navigation-bar>
        </div>
    </header>
</template>
<script setup>
import NavigationBar from './NavigationBar.vue';
</script>