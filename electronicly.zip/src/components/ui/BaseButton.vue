<template>
    <button class="text-white btn btn-secondary w-100"
    @click="$emit('clickButton')"
    >
        <slot></slot>
    </button>

</template>