<template>
  <a-carousel effect="fade">
    <div>
        <img src="../../assets/images/signup.jpg" />
        <h3>Electronics</h3>
    </div>
    <div>
        <img src="../../assets/images/jumbotron.jpg" />
        <h3>Electronics</h3>
    </div>
    <div>
        <img src="../../assets/images/insta-item1.jpg" />
        <h3>Electronics</h3>
    </div>
    <div>
        <img src="../../assets/images/insta-item2.jpg" />
        <h3>Electronics</h3>
    </div>
<!-- 
    <div>
        <img src="image2.jpg" />
        <h3>Gadgets</h3>
    </div>

    <div>
        <img src="image3.jpg" />
        <h3>Appliances</h3>
    </div>

    <div>
        <img src="image4.jpg" />
        <h3>Accessories</h3>
    </div> -->
</a-carousel>


</template>

<style scoped>
/* For demo */
:deep(.slick-slide) {
  text-align: center;
  height: 160px;
  line-height: 160px;
  background: #364d79;
  overflow: hidden;
}

:deep(.slick-slide h3) {
  color: #fff;
}
</style>