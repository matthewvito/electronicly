<template>
   

    <a-form ref="formRef" :model="formState" :rules="rules" :label-col="labelCol" :wrapper-col="wrapperCol"
        class="mt-5">
        <a-form-item ref="name" label="Category" name="category">
            <a-select v-model:value="formState.category" @change="handleCategoryChange"
                placeholder="please select your category">
                <a-select-option value="smartphone">Smartphone</a-select-option>
                <a-select-option value="watch">Watch</a-select-option>
                <a-select-option value="computer">Computer</a-select-option>
            </a-select>
        </a-form-item>



        <a-form-item label="Color" name="color">
            <a-select v-model:value="formState.color" @change="handleColorChange"
                placeholder="please select your color">
                <a-select-option value="black">Black</a-select-option>
                <a-select-option value="gray">Gray</a-select-option>
            </a-select>
        </a-form-item>




        <a-form-item label="Description" name="description">
            <a-textarea v-model:value="formState.description" />
        </a-form-item>

        <a-form-item label="Image" name="image">
            <div class="mb-3">
                <base-input label="Product Photo" type="file" identity="productImage"
                    @change="handleChangeImage"></base-input>
                <div>
                    <img :src="formState.image" :alt="formState.name" class="image"
                        style="object-fit: cover; width: 100px; height: 100px;">

                </div>
            </div>
        </a-form-item>




        <a-form-item label="Price" required name="price">
            <a-input v-model:value="formState.price" />

        </a-form-item>

        <a-form-item label="Name" required name="name">
            <a-input v-model:value="formState.name" />

        </a-form-item>

        <a-form-item label="Stock" required name="stock">
            <a-input v-model:value="formState.stock" />

        </a-form-item>

        <a-form-item :wrapper-col="{ span: 14, offset: 4 }">
            <a-button type="primary" @click="onSubmit">Edit</a-button>
            <a-button style="margin-left: 10px" @click="resetForm">Reset</a-button>
        </a-form-item>
    </a-form>


</template>
<script setup>
import BaseInput from '../ui/BaseInput.vue'
import { ref, reactive } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useStore } from 'vuex'
import { message } from 'ant-design-vue'
import { onMounted } from 'vue'

const store = useStore()
const router = useRouter()
const route = useRoute()


const formState = reactive({
    name: '',
    category: '',
    color: '',
    description: '',
    image: 'https://cdn.arstechnica.net/wp-content/uploads/2021/09/iPhone-13-Pro-Max-back.jpeg',
    price: 0,
    stock: 0
})
onMounted(async () => {
    await store.dispatch("product/getProductDetail", route.params.id)

    Object.assign(formState, store.state.product.productDetail);
})





const handleColorChange = (value) => {
    formState.color = value;
}
const handleCategoryChange = (value) => {
    formState.category = value;
}



const handleChangeImage = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);

    reader.addEventListener("load", () => {
        formState.image = reader.result;
    })
}




const onSubmit = async () => {
    // get form data
    message.loading({ content: 'Loading...', key: 'productForm' });

    // form is valid, submit data
    console.log('submit form data', formState)
    await store.dispatch('product/updateProduct', {
            id: route.params.id,
            newProduct: formState
        });
    setTimeout(() => {
        message.success({ content: 'Edit succesfull!', key: 'productForm', duration: 2 });
    }, 1000);

    router.push('/');
    return;
}

const resetForm = () => {
    formRef.value.resetFields();
};

const addNewProduct = async () => {

}

</script>