import axios from "axios";

export default {
    namespaced: true,
    state() {
        return {
            products: [],
            productDetail: {},
            cart: []
        }
    },
    getters: {},
    mutations: {
        setProductData(state, payload) {
            state.products = payload
        },
        setProductDetail(state, payload) {
            state.productDetail = payload
        },
        setNewProduct(state, payload) {
            state.products.push.payload;
        }
    },
    actions: {
        async getProductData({ commit }) {
            try {
                const { data } = await axios.get('https://electronic-store-67e91-default-rtdb.firebaseio.com/products.json')

                const arr = []
                for (let key in data) {
                    arr.push({ id: key, ...data[key] })
                }

                commit("setProductData", arr)
            } catch (err) {
                console.log(err)
            }
        },
        async getCart({ commit }) {
            try {
                const { data } = await axios.get('https://electronic-store-67e91-default-rtdb.firebaseio.com/cart.json')

                const arr = []
                for (let key in data) {
                    arr.push({ id: key, ...data[key] })
                }

                commit("setCart", arr)
            } catch (err) {
                console.log(err)
            }
        },

        async getProductDetail({ commit }, payload) {
            try {
                const { data } = await axios.get(`https://electronic-store-67e91-default-rtdb.firebaseio.com/products/${payload}.json`)

                commit("setProductDetail", data)

            } catch (err) {
                console.log(err)
            }
        },

        async addNewProduct({ commit, rootState }, payload) {
            const newData = {
                ...payload,
                username: rootState.auth.userLogin.username,
                createdAt: Date.now(),
                likes: ["null"],
                userId: rootState.auth.userLogin.userId
            }

            try {
                const { data } = await axios.post(
                    `https://electronic-store-67e91-default-rtdb.firebaseio.com/products.json?auth=${rootState.auth.token}`,
                    newData
                );
                commit('setNewProduct', { id: data.name, ...newData });
            } catch (err) {
                console.log(err)
            }
        },
        async addCart({ commit, rootState }, payload) {
            const newData = {
                ...payload,
                username: rootState.auth.userLogin.username,
                createdAt: Date.now(),

                userId: rootState.auth.userLogin.userId
            }

            try {
                const { data } = await axios.post(
                    `https://electronic-store-67e91-default-rtdb.firebaseio.com/cart.json?auth=${rootState.auth.token}`,
                    newData
                );

            } catch (err) {
                console.log(err)
            }
        },
        async deleteProduct({ dispatch, rootState }, payload) {
            try {
                const { data } = await axios.delete(`https://electronic-store-67e91-default-rtdb.firebaseio.com/products/${payload}.json?auth=${rootState.auth.token}`);
                await dispatch("getProductData");
            } catch (err) {
                console.log(err)
            }
        },

        async updateProduct({ dispatch, rootState }, { id, newProduct }) {
            try {
                const { data } = await axios.put(
                    `https://electronic-store-67e91-default-rtdb.firebaseio.com/products/${id}.json?auth=${rootState.auth.token}`,
                    newProduct
                );
                await dispatch("getProductData")
            } catch (err) {
                console.log(err);
            }

        }

    }
}